#!/bin/bash


echo "Running tests..."

npm test

echo "Testing complete."
